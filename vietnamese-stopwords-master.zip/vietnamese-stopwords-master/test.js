var stopword = require('./index');
console.log(stopword);